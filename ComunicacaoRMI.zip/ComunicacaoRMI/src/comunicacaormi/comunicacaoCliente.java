/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicacaormi;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import javax.swing.JOptionPane;

/**
 *
 * @author Gemeos
 */
public class comunicacaoCliente {
    
    
           
            
           
    public static void main(String[] args) {
        
        try{
            
            Registry x = LocateRegistry.getRegistry("127.0.0.1", 3666);
            
            ComunicacaoImplementacao z = (ComunicacaoImplementacao) x.lookup("calcular massa corporea");
            
            String cpf = JOptionPane.showInputDialog("insira seu nome: ");
            
            //System.out.println(z.BuscarNome(cpf));
           
            
            
        }catch (Exception e){
            
            e.printStackTrace();
        }
        
    }
            
        
}
