/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comunicacaormi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Gemeos
 */
public class Implementacao extends UnicastRemoteObject implements ComunicacaoImplementacao{

    float Resul4;
    float Resul5;
    
    public Implementacao()throws Exception{
        super();
    }
   
   
    DAO_IMC bd = new DAO_IMC();
    
    
    @Override
    public void Cadastra(float peso, float altura,String nome1,String CPF) {

       
        bd.connection();

        String sql = "insert into pessoa(nome, cpf , peso, altura) values (?, ?, ?, ?)";
        
        try {
           

            try (PreparedStatement stm = bd.con.prepareStatement(sql)) {
                
                stm.setString(1, nome1);
                stm.setString(2, CPF);
                stm.setFloat(3, peso);
                stm.setFloat(4, altura);
               
                
                
                
                stm.execute();
            }
            
           
         
        } catch (SQLException ex) {

            //throw new RuntimeException(ex);
           
        }
        
        
       
    }
   
    @Override
   public float BuscarNome(String nome3) {

        String Resul = null;
        bd.connection();
        PreparedStatement stmt = null;
        ResultSet Resultado = null;
        
        
        String sql = "SELECT MAX(id) FROM pessoa WHERE nome like ?";

        try {
            
            stmt = bd.con.prepareStatement(sql);
            stmt.setString(1, nome3 + "%");
            Resultado = stmt.executeQuery();

            while (Resultado.next()) {
                
                 Resul = Resultado.getString(1); 
                 //System.out.println("Maior ID: " + Resul);

            }
            
           
        } catch (SQLException ex) {

            Resul = "aaaa1";
        }
        
        
         String Resul1 = null;
         PreparedStatement stmt1 = null;
         ResultSet Resultado1 = null;
        
        
         String sql1 = "SELECT * FROM pessoa WHERE id like ?";

        try {
            
            stmt1 = bd.con.prepareStatement(sql1);
            stmt1.setString(1, Resul + "%");
            Resultado1 = stmt1.executeQuery();

            while (Resultado1.next()) {
                
                 Resul4 = Resultado1.getFloat("peso"); 
                 System.out.println("Peso da Ultima Consulta do Paciente: "+ nome3 +" ==  " +Resul4 +"Kg");

            }
            
           
        } catch (SQLException ex) {

            
        }
        
        
        
         
        
        
        String Resul2 = null;
        PreparedStatement stmt2 = null;
        ResultSet Resultado2 = null;
        
        
        String sql2 = "SELECT MIN(id) FROM pessoa WHERE nome like ?";

        try {
            
            stmt2 = bd.con.prepareStatement(sql2);
            stmt2.setString(1, nome3 + "%");
            Resultado2 = stmt2.executeQuery();

            while (Resultado2.next()) {
                
                 Resul2 = Resultado2.getString(1); 
                 //System.out.println("Menor ID: " + Resul2);
                 

            }
            
           
        } catch (SQLException ex) {

            Resul = "aaaa2";
        }
        
        
         String Resul3 = null;
         PreparedStatement stmt3 = null;
         ResultSet Resultado3 = null;
        
        
         String sql3 = "SELECT * FROM pessoa WHERE id like "+Resul2+"";

        try {
            
            stmt3 = bd.con.prepareStatement(sql3);
            Resultado3 = stmt3.executeQuery();

            while (Resultado3.next()) {
                
                 Resul5 = Resultado3.getFloat("peso"); 
                 System.out.println("Peso da Primeira Consulta do Paciente: "+ nome3 +" ==  " +Resul5 +"Kg");

            }
            
           
        } catch (SQLException ex) {

            
        }
        
        
        float resultado = Resul5 - Resul4;
        
        
       
        
        
        return resultado;
      
       
        
    }

    
}
