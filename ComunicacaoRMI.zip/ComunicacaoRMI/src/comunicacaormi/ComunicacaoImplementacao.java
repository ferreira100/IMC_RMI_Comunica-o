
package comunicacaormi;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface ComunicacaoImplementacao extends Remote {
    
    public void Cadastra(float peso, float altura,String nome1,String CPF)throws RemoteException;
    
    public float BuscarNome(String nome3)throws RemoteException;
    
}
